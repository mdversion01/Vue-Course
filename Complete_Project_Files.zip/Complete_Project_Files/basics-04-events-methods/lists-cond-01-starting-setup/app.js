const app = Vue.createApp({
  data() {
    return { goals: [] };
  },
});

app.mount('#user-goals');
