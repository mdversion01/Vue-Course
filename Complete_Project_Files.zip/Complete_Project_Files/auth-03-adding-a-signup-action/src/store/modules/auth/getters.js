export default {
  userId(state) {
    return state.userId;
  }
};